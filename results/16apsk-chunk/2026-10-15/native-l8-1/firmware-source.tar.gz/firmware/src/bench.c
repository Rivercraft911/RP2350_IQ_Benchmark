#include "bench.h"

#include <stdio.h>
#include <string.h>

#include "dvbs2.h"
#include "dvbs2_8psk.h"
#include "dvbs2_codes.h"
#include "hardware/clocks.h"
#include "hardware/dma.h"
#include "hardware/sync.h"
#include "iq8.h"
#include "pvproto.h"
#include "tx.h"

#include "git_rev.h"

void bench_8map(int code, bool pilots, int reps) {
    const dvbs2_code_t *c = &DVBS2_CODES[code];
    dvbs2_8psk_cfg_t profile;
    const uint32_t arena_words = dvbs2_8psk_arena_words(c, pilots);
    if (!arena_words || arena_words > TABLE_WORDS) {
        printf("@{\"error\":\"unsupported 8PSK code\"}\n");
        return;
    }
    tx_code(code, pilots);
    if (!dvbs2_8psk_init(&profile, c, pilots, 0, cfg.ti, TABLE_WORDS)) {
        iq_build_tables(&cfg);
        printf("@{\"error\":\"8PSK mapper setup failed\"}\n");
        return;
    }
    const uint32_t t0 = cycles();
    dvbs2_frame_begin(bb_buf);
    const uint32_t frontend = cycles() - t0, t1 = cycles();
    dvbs2_frame_ldpc();
    const uint32_t ldpc = cycles() - t1;
    dvbs2_8psk_stream_t stream = {.out = (iq8_input_t *)cap_buf, .mask = ~0u};
    dvbs2_8psk_frame(&profile, dvbs2_frame_buffer(), &stream);
    dvbs2_8psk_flush(&stream);
    const uint32_t crc = crc32_update(0, cap_buf, stream.n * sizeof(iq8_input_t));
    stream = (dvbs2_8psk_stream_t){.out = (iq8_input_t *)cap_buf, .mask = 4095};
    uint64_t elapsed = 0;
    uint32_t worst = 0;
    for (int r = 0; r < reps; ++r) {
        const uint32_t saved = save_and_disable_interrupts(), start = cycles();
        dvbs2_8psk_frame(&profile, dvbs2_frame_buffer(), &stream);
        const uint32_t dt = cycles() - start;
        restore_interrupts(saved);
        elapsed += dt;
        if (dt > worst) worst = dt;
    }
    printf("@{\"cmd\":\"bench8map\",\"git\":\"%s\",\"clk_hz\":%lu,"
           "\"code_index\":%d,\"code\":\"%s\",\"pilots\":%u,\"gold\":0,"
           "\"modcod\":%u,\"frame_symbols\":%lu,\"arena_bytes\":%lu,\"reps\":%d,"
           "\"bb_bch_cyc\":%lu,\"ldpc_cyc\":%lu,\"map_cyc\":%.1f,\"map_worst_cyc\":%lu,\"crc\":%lu}\n",
           GIT_REV, (unsigned long)clock_get_hz(clk_sys), code, c->name, pilots,
           profile.modcod, (unsigned long)profile.frame_symbols, (unsigned long)arena_words * 4,
           reps, (unsigned long)frontend, (unsigned long)ldpc, (double)elapsed / reps,
           (unsigned long)worst, (unsigned long)crc);
    iq_build_tables(&cfg);
}

// Kernel throughput over the whole PRBS input. The first pass computes the output CRC, outside
// the timing; the timed passes run with interrupts off.
void bench_kernel(const iq_kernel_info_t *k, int reps, bool tables_ok) {
    const uint32_t bw = BLOCK_WORDS, biw = BLOCK_IN(cfg.sps), nblk = IN_WORDS / biw;
    uint32_t crc = 0, worst = 0;
    uint64_t cyc = 0;                                // conv overflows 32 bits after 36 reps
    for (uint32_t b = 0; b < nblk; b++) {
        uint32_t *o = ring_buf + (b % N_BLOCKS) * bw;
        k->fn(o, in_buf + b * biw, biw, b ? in_buf[b * biw - 1] : 0, &cfg);
        crc = crc32_update(crc, o, bw * 4);
    }
    const uint32_t save = save_and_disable_interrupts();
    for (int r = 0; r < reps; r++)
        for (uint32_t b = 0; b < nblk; b++) {
            const uint32_t t0 = cycles();
            k->fn(ring_buf + (b % N_BLOCKS) * bw, in_buf + b * biw, biw,
                  in_buf[(b * biw + IN_WORDS - 1) % IN_WORDS], &cfg);
            const uint32_t dt = cycles() - t0;
            cyc += dt;
            if (dt > worst) worst = dt;
        }
    restore_interrupts(save);
    const double syms = (double)reps * IN_WORDS * 16, cps = cyc / syms;
    tx_json_head("bench", k);
    printf(",\"seed\":%lu,\"in_words\":%d,\"reps\":%d,\"tables_ok\":%d,\"crc\":%lu,"
           "\"cyc_per_sym\":%.4f,\"worst_block_cyc_per_sym\":%.4f,\"msym_s_one_core\":%.4f}\n",
           (unsigned long)SEED, IN_WORDS, reps, tables_ok, (unsigned long)crc, cps,
           (double)worst / BLOCK_SYMS(cfg.sps), clock_get_hz(clk_sys) / cps / 1e6);
}

// ------------------------------------------------------------------ DVB-S2 encoder stages

static uint32_t par_buf[BB_WORDS] SRAM_HI, bb_save[BB_WORDS] SRAM_HI;
static const dvbs2_code_t *c;
static int ci;

static uint32_t time_min(void (*f)(void), int reps) {
    uint32_t best = ~0u;
    for (int r = 0; r < reps; r++) {
        const uint32_t save = save_and_disable_interrupts(), t0 = cycles();
        f();
        const uint32_t dt = cycles() - t0;
        restore_interrupts(save);
        if (dt < best) best = dt;
    }
    return best;
}

static volatile uint8_t pv_bench_crc;
static uint32_t pv_bench_packet;

static void t_pv_crc8(void) {
    pv_bench_crc = pv_crc8((uint8_t *)cap_buf + 13, PV_TS - 1);
}

static uint8_t *pv_bench_next(void) {
    return (uint8_t *)cap_buf + 12 + PV_TS * (pv_bench_packet++ % 7);
}

static void t_pv_frame(void) {
    pv_bbframe((uint8_t *)bb_buf, 43040, 0xF2, pv_bench_next);
}

void bench_pv(int reps) {
    pv_init(65536);
    pv_pattern_message((uint8_t *)cap_buf, 0, 65536);
    pv_bench_packet = 0;
    const uint32_t crc_cyc = time_min(t_pv_crc8, reps);
    const uint32_t frame_cyc = time_min(t_pv_frame, reps);
    printf("@{\"cmd\":\"pvbench\",\"git\":\"%s\",\"clk_hz\":%lu,\"reps\":%d,"
           "\"crc8_bytes\":187,\"crc8\":%u,\"crc8_cyc\":%lu,\"bbframe_cyc\":%lu}\n",
           GIT_REV, (unsigned long)clock_get_hz(clk_sys), reps, pv_bench_crc,
           (unsigned long)crc_cyc, (unsigned long)frame_cyc);
}

static void t_bch(void) { dvbs2_bch(bb_buf, par_buf); }
static void t_bch_serial(void) { dvbs2_bch_serial(bb_buf, par_buf); }
static void t_ldpc(void) { dvbs2_ldpc(bb_buf, par_buf); }
static void t_ldpc_serial(void) { dvbs2_ldpc_serial(bb_buf, par_buf); }
static void t_prbs(void) {                                     // input fill, subtracted
    uint32_t st = 1;
    prbs_fill(bb_buf, (c->kbch + 31) / 32, &st);
}
static void t_frame(void) {
    uint32_t st = 0x9E3779B9u ^ (uint32_t)ci;
    prbs_fill(bb_buf, (c->kbch + 31) / 32, &st);              // fresh input each run (not timed apart)
    symstream_t s = {.out = cap_buf, .mask = ~0u};
    dvbs2_frame(bb_buf, &s);
}

// One PLFRAME of the test BBFRAME into cap_buf (CRC'd against the host reference), then the
// minimum cycles of each stage over reps runs.
void bench_dvbs2(int code, bool pilots, int reps) {
    ci = code, c = &DVBS2_CODES[code];
    const uint32_t init_us = tx_code(code, pilots);
    uint32_t st = 0;
    symstream_t s = {.out = cap_buf, .mask = ~0u};
    dvbs2_frame(bb_buf, &s);
    symstream_flush(&s);
    const uint32_t crc = crc32_update(0, cap_buf, s.n * 4);
    memcpy(bb_save, bb_buf, sizeof bb_save);                   // timing runs clobber bb_buf
    for (uint32_t k = 0; k < BB_WORDS; k++) bb_buf[k] = st = st * 1664525u + 1013904223u;
    const uint32_t c_bch = time_min(t_bch, reps), c_bchs = time_min(t_bch_serial, 1);
    const uint32_t c_ldpc = time_min(t_ldpc, reps), c_ldpcs = time_min(t_ldpc_serial, 1);
    const uint32_t c_frame = time_min(t_frame, reps), c_prbs = time_min(t_prbs, reps);
    printf("@{\"cmd\":\"dvbs2\",\"git\":\"%s\",\"clk_hz\":%lu,\"code\":\"%s\",\"index\":%d,"
           "\"pilots\":%d,\"syms\":%lu,\"words\":%lu,\"crc\":%lu,\"init_us\":%lu,\"reps\":%d,\"bch_kernel\":%d,\"map_kernel\":%u,"
           "\"cyc_bch\":%lu,\"cyc_bch_serial\":%lu,\"cyc_ldpc\":%lu,\"cyc_ldpc_serial\":%lu,"
           "\"cyc_frame\":%lu,\"prof\":{\"ldpc_groups\":%lu,\"ldpc_accum\":%lu,"
           "\"ldpc_transpose\":%lu,\"f_bb_bch\":%lu,\"f_ldpc\":%lu,\"f_map\":%lu}}\n",
           GIT_REV, (unsigned long)clock_get_hz(clk_sys), c->name, code, pilots,
           (unsigned long)dvbs2_plframe_symbols(), (unsigned long)s.n, (unsigned long)crc,
           (unsigned long)init_us, reps, dvbs2_bch_get_kernel(), dvbs2_map_get_kernel(), (unsigned long)c_bch, (unsigned long)c_bchs,
           (unsigned long)c_ldpc, (unsigned long)c_ldpcs, (unsigned long)(c_frame - c_prbs),
           (unsigned long)(dvbs2_prof[1] - dvbs2_prof[0]), (unsigned long)(dvbs2_prof[2] - dvbs2_prof[1]),
           (unsigned long)(dvbs2_prof[3] - dvbs2_prof[2]), (unsigned long)(dvbs2_prof[5] - dvbs2_prof[4]),
           (unsigned long)(dvbs2_prof[6] - dvbs2_prof[5]), (unsigned long)(dvbs2_prof[7] - dvbs2_prof[6]));
    memcpy(bb_buf, bb_save, sizeof bb_save);
}

// ------------------------------------------------------------------ DMA sniffer modes

// CRC of pattern message 0 (1328 data bytes, and all 1332 incl. its CRC) for every mode /
// byte-swap / output-reverse / output-invert combination, seed 0xFFFFFFFF.
void bench_sniffer(void) {
    uint32_t *msgw = cap_buf, *dst = cap_buf + 512;
    pv_init(65536);
    pv_pattern_message((uint8_t *)msgw, 0, 65536);
    const int ch = dma_claim_unused_channel(true);
    printf("@{\"cmd\":\"snifftest\",\"sw_crc\":%lu,\"r\":[", (unsigned long)pv_crc32(0, msgw, 1328));
    for (int m = 0; m < 16; m++) {
        uint32_t out[2];
        for (int n = 0; n < 2; n++) {
            dma_channel_config d = dma_channel_get_default_config(ch);
            channel_config_set_transfer_data_size(&d, DMA_SIZE_32);
            channel_config_set_sniff_enable(&d, true);
            dma_sniffer_enable(ch, m & 1 ? DMA_SNIFF_CTRL_CALC_VALUE_CRC32R : DMA_SNIFF_CTRL_CALC_VALUE_CRC32, true);
            dma_sniffer_set_byte_swap_enabled(m & 2);
            dma_sniffer_set_output_reverse_enabled(m & 4);
            dma_sniffer_set_output_invert_enabled(m & 8);
            dma_sniffer_set_data_accumulator(0xFFFFFFFFu);
            dma_channel_configure(ch, &d, dst, msgw, n ? 333 : 332, true);
            dma_channel_wait_for_finish_blocking(ch);
            out[n] = dma_sniffer_get_data_accumulator();
        }
        printf("%s[%d,%lu,%lu]", m ? "," : "", m, (unsigned long)out[0], (unsigned long)out[1]);
    }
    dma_sniffer_disable();
    dma_channel_unclaim(ch);
    printf("]}\n");
}

// Isolated 8PSK shaping, not a DVB-S2 8PSK encoder or a streaming measurement. The two
// unflagged amplitude-plane tables borrow cfg.ti/tq; restore the QPSK tables afterward.
void bench_8psk(int reps) {
    const iq_kernel_info_t *k;
    bool tables_ok;
    const char *e = tx_shaper("lut_asm_p", 4, 12, &k, &tables_ok);
    if (e || !tables_ok) {
        printf("@{\"error\":\"8PSK baseline tables unavailable\"}\n");
        return;
    }
    const iq8_tables_t tables = {cfg.ti, cfg.tq};
    const uint32_t groups = IN_WORDS / 2, block = BLOCK_WORDS / (16 * IQ8_SPS);
    iq8_input_t *in = (iq8_input_t *)in_buf;
    uint32_t seed = SEED;
    iq8_fill(in, groups, &seed);
    iq8_build_tables(cfg.coef, &tables);
    uint32_t crc_c = 0, crc_asm = 0, worst = 0;
    uint64_t elapsed = 0;
    for (uint32_t g = 0; g < groups; g += block) {
        const iq8_input_t *prev = g ? in + g - 1 : NULL;
        iq8_kernel_c(ring_buf, in + g, block, prev, &tables);
        crc_c = crc32_update(crc_c, ring_buf, BLOCK_WORDS * sizeof(uint32_t));
        iq8_kernel_asm(ring_buf, in + g, block, prev, &tables);
        crc_asm = crc32_update(crc_asm, ring_buf, BLOCK_WORDS * sizeof(uint32_t));
    }
    for (int r = 0; r < reps; r++) {
        for (uint32_t g = 0; g < groups; g += block) {
            const uint32_t save = save_and_disable_interrupts(), t0 = cycles();
            iq8_kernel_asm(ring_buf, in + g, block, g ? in + g - 1 : NULL, &tables);
            const uint32_t dt = cycles() - t0;
            restore_interrupts(save);
            elapsed += dt;
            if (dt > worst) worst = dt;
        }
    }
    const double cps = (double)elapsed / ((double)reps * groups * 16);
    printf("@{\"cmd\":\"bench8psk\",\"git\":\"%s\",\"clk_hz\":%lu,\"seed\":%lu,"
           "\"sps\":4,\"L\":12,\"groups\":%lu,\"reps\":%d,\"table_bytes\":65536,"
           "\"crc_c\":%lu,\"crc_asm\":%lu,\"crc_match\":%u,\"cyc_per_sym\":%.4f,"
           "\"worst_block_cyc_per_sym\":%.4f,\"msym_s_one_core\":%.4f}\n",
           GIT_REV, (unsigned long)clock_get_hz(clk_sys), (unsigned long)SEED,
           (unsigned long)groups, reps, (unsigned long)crc_c, (unsigned long)crc_asm,
           crc_c == crc_asm, cps, (double)worst / (block * 16),
           clock_get_hz(clk_sys) / cps / 1e6);
    iq_build_tables(&cfg);
    seed = SEED;
    prbs_fill(in_buf, IN_WORDS, &seed);
}
