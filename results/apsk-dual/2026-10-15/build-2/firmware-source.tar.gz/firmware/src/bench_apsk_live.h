// Runtime geometric-label mapping, shaping, and digital output; no FEC/RF.
#pragma once
// schedule 0: core 0 maps/shapes; 1: core 1 maps, core 0 shapes;
// 2: both cores map/shape alternate output blocks. cpw 3..8, 100..60000 ms.
void bench_apsk_live(int cpw, int ms, int schedule);
