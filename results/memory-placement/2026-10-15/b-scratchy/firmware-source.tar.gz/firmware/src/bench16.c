#include "bench.h"
#include "iq16chunk.h"
#include "tx.h"

#include <stdio.h>
#include "git_rev.h"
#include "hardware/clocks.h"
#include "hardware/sync.h"

enum { BLOCKS = IN_WORDS, CHUNK = 256, WORDS = CHUNK * 8 };
_Static_assert(2 * IQ16CHUNK_TABLE_WORDS == N_BLOCKS * BLOCK_WORDS, "16APSK table arena");
_Static_assert(WORDS <= CAP_WORDS_MAX, "16APSK output arena");
_Static_assert(2 * IQ16CHUNK_ROWS <= 4 * TABLE_WORDS, "key reversal arena");

static uint32_t masked_crc(uint32_t crc, const uint32_t *pairs) {
    for (unsigned k = 0; k < WORDS; k += 2) {
        const uint32_t packed[2] = {
            (pairs[k] & 0x3fffu) | (pairs[k + 1] & 0x3fffu) << 16,
            ((pairs[k] >> 16) & 0x3fffu) | (pairs[k + 1] & 0x3fff0000u),
        };
        crc = crc32_update(crc, packed, sizeof packed);
    }
    return crc;
}

void bench_16chunk(int reps) {
    iq16chunk_tables_t tables = {ring_buf, ring_buf + IQ16CHUNK_TABLE_WORDS, NULL};
    uint16_t *reverse = (uint16_t *)cfg.ti;
    if (!iq16chunk_build(&tables, IQ16CHUNK_DEFAULT_GAMMA100)) {
        printf("@{\"error\":\"16APSK table construction failed\"}\n");
        return;
    }
    iq16chunk_build_reverse(reverse);
    uint32_t seed = SEED;
    iq16chunk_fill(in_buf, BLOCKS, &seed);
    const uint32_t ci = crc32_update(0, in_buf, BLOCKS * 4);
    const uint32_t ce = crc32_update(0, tables.edge, IQ16CHUNK_TABLE_WORDS * 4);
    const uint32_t cm = crc32_update(0, tables.middle, IQ16CHUNK_TABLE_WORDS * 4);
    struct measurement { uint32_t raw, crc, worst; uint64_t elapsed; bool correct; } measured[2];
    for (unsigned mode = 0; mode < 2; ++mode) {
        tables.reverse = mode ? reverse : NULL;
        uint32_t crc = 0, raw = 0, worst = 0;
        uint64_t elapsed = 0;
        for (unsigned b = 0; b < BLOCKS; b += CHUNK) {
            iq16chunk_kernel_c(cap_buf, in_buf + b, CHUNK, b ? in_buf + b - 2 : NULL, &tables);
            crc = masked_crc(crc, cap_buf);
            raw = crc32_update(raw, cap_buf, WORDS * 4);
        }
        for (int r = 0; r < reps; ++r) {
            for (unsigned b = 0; b < BLOCKS; b += CHUNK) {
                const uint32_t saved = save_and_disable_interrupts(), start = cycles();
                iq16chunk_kernel_c(cap_buf, in_buf + b, CHUNK, b ? in_buf + b - 2 : NULL, &tables);
                const uint32_t dt = cycles() - start;
                restore_interrupts(saved);
                elapsed += dt;
                if (dt > worst) worst = dt;
            }
        }
        const bool correct = ci == IQ16CHUNK_FIXTURE_INPUT_CRC && ce == IQ16CHUNK_EDGE_CRC &&
            cm == IQ16CHUNK_MIDDLE_CRC && raw == IQ16CHUNK_FIXTURE_RAW_PAIRS_CRC &&
            crc == IQ16CHUNK_FIXTURE_PACKED_CRC;
        measured[mode] = (struct measurement){raw, crc, worst, elapsed, correct};
    }
    printf("@{\"cmd\":\"bench16chunk\",\"git\":\"%s\",\"clk_hz\":%lu,\"reps\":%d,"
           "\"L\":9,\"sps\":2,\"gamma100\":270,\"table_bytes\":131072,"
           "\"input_crc\":%lu,\"edge_crc\":%lu,\"middle_crc\":%lu,"
           "\"code_placement\":\"flash_cached\",\"kernels\":[",
           GIT_REV, (unsigned long)clock_get_hz(clk_sys), reps,
           (unsigned long)ci, (unsigned long)ce, (unsigned long)cm);
    for (unsigned mode = 0; mode < 2; ++mode) {
        const struct measurement *r = &measured[mode];
        printf("%s{\"name\":\"%s\",\"raw_crc\":%lu,\"packed_crc\":%lu,\"crc_ok\":%s,"
               "\"reverse_bytes\":%u,\"cyc_per_sym\":%.4f,\"worst_block_cyc_per_sym\":%.4f}",
               mode ? "," : "", mode ? "reverse_map" : "reverse_bits",
               (unsigned long)r->raw, (unsigned long)r->crc, r->correct ? "true" : "false",
               mode ? IQ16CHUNK_ROWS * 2 : 0, (double)r->elapsed / (reps * BLOCKS * 4),
               (double)r->worst / (CHUNK * 4));
    }
    printf("]}\n");
    iq_build_tables(&cfg);
    seed = SEED;
    prbs_fill(in_buf, IN_WORDS, &seed);
}
